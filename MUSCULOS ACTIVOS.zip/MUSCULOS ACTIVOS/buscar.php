

<!DOCTYPE html>
<html>
<head>
 <title>FORMULARIO DE CONSULTA</title>
<link href="gym.png" rel="shortcut icon">
</head>
<center>

<h4 align="CENTER">BUSCAR CLIENTE</h4>
<form   action="buscar.php"  method="POST" >
<input type="text" name="usuario" placeholder="insertar el usuario a consultar">

 <input type="submit" name="Buscar"> 
  

</form>
</center>
<div>
  <table border="2" align="center">
    
    <tr>
               
              <th>NOMBRE COMPLETO</th>
              <th>TELEFONO</th>
              <th>FECHA INICIO</th>
              <th>FECHA FIN</th>
              <th>MENSUALIDAD</th>
              <th>PESO</th>
              <th>ESPALDA</th>
              <th>PECHO</th>
              <th>BRAZO</th>
              <th>CINTURA</th>
              <th>CADERA</th>
              <th>PIERNA</th>
              <th>PANTORILLA</th>
              



              





    </tr>

    <?php 
$conexion=mysqli_connect('localhost','root','','gym');

$usuario = $_POST["usuario"];

echo "EL CLIENTE BUSCADO ES: ".$usuario . "<br>";



$consulta = "SELECT * FROM clientes WHERE telefono= '$usuario' ";

$resultado = mysqli_query($conexion,$consulta);

$encontrado = mysqli_num_rows($resultado);

if ($encontrado==0) {

  echo "no existe el cliente ";
 
}



while($datos= mysqli_fetch_array($resultado)){
?>
  
  <BR>
<tr align="CENTER">
              <td><?php echo $datos['nombre_compl'] ?></td>
              <td><?php echo $datos['telefono'] ?></td>
              <td><?php echo $datos['fecha_inic'] ?></td>
              <td><?php echo $datos['fecha_fin'] ?></td>
              <td><?php echo $datos['mensualdiad'] ?></td>
              <td><?php echo $datos['peso'] ?></td>
              <td><?php echo $datos['espalda'] ?></td>
              <td><?php echo $datos['pecho'] ?></td>
              <td><?php echo $datos['brazo'] ?></td>
              <td><?php echo $datos['cintura'] ?></td>
              <td><?php echo $datos['cadera']?></td>
              <td><?php echo $datos['pierna']?></td>
              <td><?php echo $datos['pantorilla']?></td>

             
</tr>
          <?php 
}
          ?>


            

  </table>

</div>

</html>
<body>

</body>

<div id=layer1  class="controls" style="position:absolute; top:59px; left:1000px" name="DATOS">
<td><a href="http://localhost/MUSCULOS%20ACTIVOS/index.php">NUEVO INGRESO DE DATOS & INICIO</td>  
<br>
<br>
<br>
<br>


