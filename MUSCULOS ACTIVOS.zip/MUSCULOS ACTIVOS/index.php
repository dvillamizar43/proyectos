
<?php  
$conexion=mysqli_connect('localhost','root','','gym');
?>


<!DOCTYPE html>
<html>
<title>GYM MUSCULOS ACTIVOS</title>
<link href="gym.png" rel="shortcut icon">
<style>
	
     table ,th,td{

     border: 2px solid black;

}

th, td{

	padding: 10px;
}

th{

	text-align: center;
}

td{

	text-align: center;
}

input{

	text-align: center;
}

tr{

	text-align: center;
}

label{

 color: red;
}

input{

	color :red;
}

select{

	color: red;
}

table{

	color: red;
}



</style>
	<head>
	<link rel="stylesheet" type="text/css" href="estilo.css">

	
	

	</head>

	<body>

   		

		<section class="form-register">

			<div style="position:absolute; top:400px; left:214px">

	<h4 align="CENTER">FORMULARIO DE INGRESO</h4>
		
	     </div>
			
		<center>
		<form action="conexion.php" method="POST">

			<br>
			<label>NOMBRE COMPLETO</label><br>
			<input  class="controls" type="text" name="nombre" >
			
			<br>	
			<label>TELEFONO</label><br>
			<input  class="controls" type="text" name="telefono">
            
			<br>	
			<label>FECHA INICIO</label><br>
			<input  class="controls" type="date" name="fecha_inic">

		    <br>	
			<label>FECHA FINAL</label><br>
			<input  class="controls" type="date" name="fecha_fin">
			<br>

            <br>	
			<label>ABONO O MENSUALIDAD</label><br>
			<select class="controls"  type="text" name="mensualidad">
				  <option value="ABONA">-----</option>
				  <option value="ABONA">ABONA</option>
				  <option value="PAGA COMPLETO">PAGA COMPLETO</option>
				  
				</select>
			<br>

            <br>	
			<label>PESO</label><br>
			<input class="controls" type="numero" name="peso">
			
			<br>	
			<label>ESPALDA</label><br>
			<input class="controls" type="numero" name="espalda">

			<br>	
			<label>PECHO</label><br>
			<input class="controls"  type="numero" name="pecho">

			<br>	
			<label>BRAZO</label><br>
			<input class="controls" type="numero" name="brazo">

			<br>	
			<label>CINTURA</label><br>
			<input class="controls" type="numero" name="cintura">

			<br>	
			<label>CADERA</label><br>
			<input class="controls"  type="numero" name="cadera">

			<br>	
			<label>PIERNA</label><br>
			<input class="controls"  type="numero" name="pierna">

			
             <br>	
			<label>PANTORILLA</label><br>
			<input class="controls"  type="numero" name="pantorilla">

             <br>
             <br>
		<button class="controls" type="submit" name="enviar">ENVIAR</button>
		<label style="position:absolute; top:180px; left:130px">ELIMINAR CLIENTE MEDIANTE SU NUMERO DE TELEFONO</label><br>
		<label style="position:absolute; top:500px; left:130px">Dar click en "PARA CONSULTAR CLIENTE" A BUSCAR MSACT</label><br>
		<div style="position:absolute; top:120px; left:300px">
		<button   class="controls" type="submit" name="eliminar">ElIMINAR</button>
		
	     </div>
		

</center>
</section>


	</head>

	<br>
<CENTER>
	<table align=" center" border="4" style="position:absolute; left:214px >
	
     <tr align="center">
           	  <th>CODIGO</th>
              <th>NOMBRE COMPLETO</th>
              <th>TELEFONO</th>
              <th>FECHA INICIO</th>
              <th>FECHA FIN</th>
              <th>MESUALIDAD</th>
             
              
        
          </tr>

        <?php  
         
         $sql="SELECT *  FROM clientes";
       
         $resultado=mysqli_query($conexion,$sql);   

         while($mostrar=mysqli_fetch_array($resultado)){

         ?>
        

    	<tr align="center">
            
              <td ><?php echo $mostrar['id_clientes'] ?></td >	
              <td ><?php echo $mostrar['nombre_compl'] ?></td>
              <td ><?php echo $mostrar['telefono'] ?></td>
              <td ><?php echo $mostrar['fecha_inic'] ?></td>
              <td ><?php echo $mostrar['fecha_fin'] ?></td>
              <td ><?php echo $mostrar['mensualdiad'] ?></td>
              
             
             
           
          </tr>

          
          <?php 
}
          ?>



	
</CENTER>
</table>
<label style="position:absolute; top:180px; left:130px">ELIMINAR CLIENTE MEDIANTE SU NUMERO DE TELEFONO</label><br>
<div id=layer1  class="controls" style="position:absolute; top:400px; left:270px" name="consultarcliente">
	<td><a href="http://localhost/MUSCULOS%20ACTIVOS/buscar.php">CONSULTAR CLIENTE</td>  

</div>
	</body>
	