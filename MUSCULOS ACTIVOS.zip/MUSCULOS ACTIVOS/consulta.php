<?php 

$conexion=mysqli_connect('localhost','root','','gym');

$usuario = $_POST["usuario"];

echo "el cliente buscado es: ".$usuario . "<br>";



$consulta = "SELECT * FROM clientes,ingreso WHERE telefono= '$usuario' ";

$resultado = mysqli_query($conexion,$consulta);

$encontrado = mysqli_num_rows($resultado);

if ($encontrado==0) {

	echo "no existe el cliente ";
 
}



while($datos= mysqli_fetch_array($resultado)){

	



               echo $datos['nombre_compl'] ;
               echo $datos['telefono'] ;
               echo $datos['fecha_inic'] ;
               echo $datos['fecha_fin'] ;
               echo $datos['mensualdiad'];
               echo $datos['peso']; 


}

mysqli_free_result($resultado);
mysqli_close($conexion);


 ?>

 