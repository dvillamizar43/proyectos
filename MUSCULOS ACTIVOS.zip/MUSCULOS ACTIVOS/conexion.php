<?php
$conexion = mysqli_connect('localhost','root','','gym')
or die(mysql_error($mysqli));



direferencia($conexion); 

function direferencia($conexion){

	if (isset($_POST['enviar'])){
		insertar($conexion);
	}

	if (isset($_POST['eliminar'])){
		eliminar($conexion);
	}
}

eliminar($conexion);
function eliminar($conexion){

$telefono = $_POST['telefono'];

	$consulta = "DELETE  FROM clientes WHERE telefono='$telefono'";
	mysqli_query($conexion,$consulta);
    mysqli_close($conexion);

	header("location: index.php");


	}





insertar($conexion);

function insertar($conexion){
   
	$nombre = $_POST['nombre'];
	$telefono = $_POST['telefono'];
	$fecha_inic= $_POST['fecha_inic'];
	$fecha_fin = $_POST['fecha_fin'];
	$mensualidad = $_POST['mensualidad'];
	$peso = $_POST['peso'];
	$espalda = $_POST['espalda'];
	$pecho = $_POST['pecho'];
	$brazo = $_POST['brazo'];
	$cintura = $_POST['cintura'];
	$cadera = $_POST['cadera'];
	$pierna = $_POST['pierna'];
	$pantorilla = $_POST['pantorilla'];

 $consulta = "INSERT  INTO clientes(nombre_compl,telefono,fecha_inic,fecha_fin,mensualdiad,peso,espalda,pecho,brazo,cintura,cadera,pierna,pantorilla) VALUES ('$nombre','$telefono','$fecha_inic','$fecha_fin','$mensualidad', '$peso','$espalda','$pecho','$brazo','$cintura','$cadera','$pierna','$pantorilla')";

    mysqli_query($conexion, $consulta,);

	mysqli_close($conexion);
	header("location: index.php");


}

function cargarTabla($conexion){


	$consulta = "SELECT * FROM clientes";
	$resultado = mysqli_query($conexion,$consulta);


	while($fila = mysqli_fetch_array($resultado)){

		echo "<tr>";

        echo "<td>".$fila['nombre_compl'];
        echo "<td>".$fila['telefono'];

		echo "<tr>";


	}

	mysqli_close($conexion);

}




?>



//$consulta2 = "INSERT INTO ingreso(peso,espalda, pecho,brazo,cintura,cadera, pierna, pantorilla) VALUES ('$peso','$espalda','$pecho','$brazo','$cintura','$cadera','$pierna','$pantorilla')";

  //  mysqli_query($conexion, $consulta2,);